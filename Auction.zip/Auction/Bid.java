/**
 * Representa um lance: quem deu e qual o valor.
 */
public class Bid {
    private Person bidder;
    private int value;

    public Bid(Person bidder, int value) {
        this.bidder = bidder;
        this.value = value;
    }

    public Person getBidder() {
        return bidder;
    }

    public int getValue() {
        return value;
    }

    public String toString() {
        return bidder.getName() + " : " + value;
    }
}
