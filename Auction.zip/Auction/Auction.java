import java.util.ArrayList;

/**
 * Representa um leilão de vários lotes.
 * Permite registrar lances, listar e remover lotes.
 */
public class Auction {
    private ArrayList<Lot> lots;
    private int nextLotNumber;

    /**
     * Cria um novo leilão.
     */
    public Auction() {
        lots = new ArrayList<Lot>();
        nextLotNumber = 1;
    }

    /**
     * Insere um novo lote com a descrição informada.
     */
    public void enterLot(String description) {
        lots.add(new Lot(nextLotNumber, description));
        nextLotNumber++;
    }

    /**
     * Exibe todos os lotes.
     */
    public void showLots() {
        for (Lot lot : lots) {
            System.out.println(lot.toString());
        }
    }

    // =====================================================
    // Exercício 4.28
    // =====================================================
    /**
     * Fecha o leilão, exibindo todos os lotes e seus resultados.
     * Mostra quem venceu e o valor, ou indica "não vendido".
     */
    public void close() {
        System.out.println("\n*** FECHANDO LEILÃO ***");
        for (Lot lot : lots) {
            System.out.println("Lote nº " + lot.getNumber() + ": " + lot.getDescription());
            Bid highest = lot.getHighestBid();
            if (highest != null) {
                System.out.println("   Vendido para: " + highest.getBidder().getName());
                System.out.println("   Valor: " + highest.getValue());
            } else {
                System.out.println("   *** Lote não vendido ***");
            }
        }
    }

    // =====================================================
    // Exercício 4.29
    // =====================================================
    /**
     * Retorna uma lista contendo todos os lotes não vendidos.
     */
    public ArrayList<Lot> getUnsold() {
        ArrayList<Lot> unsold = new ArrayList<Lot>();
        for (Lot lot : lots) {
            if (lot.getHighestBid() == null) {
                unsold.add(lot);
            }
        }
        return unsold;
    }

    // =====================================================
    // Exercício 4.31
    // =====================================================
    /**
     * Retorna o lote com o número informado.
     * Agora busca pelo campo lotNumber, não pelo índice.
     */
    public Lot getLot(int number) {
        for (Lot lot : lots) {
            if (lot.getNumber() == number) {
                return lot;
            }
        }
        System.out.println("Lote " + number + " não encontrado.");
        return null;
    }

    // =====================================================
    // Exercício 4.32
    // =====================================================
    /**
     * Remove o lote com o número de lote informado.
     * @param number número do lote a ser removido
     * @return o Lote removido, ou null se não existir
     */
    public Lot removeLot(int number) {
        for (Lot lot : lots) {
            if (lot.getNumber() == number) {
                lots.remove(lot);
                System.out.println("Lote " + number + " removido com sucesso!");
                return lot;
            }
        }
        System.out.println("Lote " + number + " não encontrado.");
        return null;
    }

    // =====================================================
    // Exercício 4.33
    // =====================================================
    /**
     * Compara o desempenho de ArrayList e LinkedList.
     * (Análise teórica, não implementável dentro da classe.)
     *
     * ➤ Ambas pertencem ao pacote java.util.
     * ➤ Métodos em comum:
     *    - add(), remove(), get(), size(), clear(), contains(), isEmpty(), iterator()
     * ➤ Diferenças principais:
     *    - ArrayList é mais rápida para acesso por índice (get/set).
     *    - LinkedList é mais eficiente para inserções/remoções frequentes
     *      em posições intermediárias.
     *    - ArrayList usa um array dinâmico; LinkedList usa nós encadeados.
     *
     * Portanto, em leilões com poucas remoções e muitas leituras,
     * ArrayList é a melhor escolha (como no projeto Auction).
     */
}
