/**
 * Representa um lote do leilão.
 */
public class Lot {
    private int number;
    private String description;
    private Bid highestBid; // null se nenhum lance

    public Lot(int number, String description) {
        this.number = number;
        this.description = description;
        this.highestBid = null;
    }

    public int getNumber() {
        return number;
    }

    public String getDescription() {
        return description;
    }

    /**
     * Retorna o maior lance já feito (ou null se nenhum).
     */
    public Bid getHighestBid() {
        return highestBid;
    }

    /**
     * Tenta registrar um lance. Só aceita se o valor for maior que o atual.
     * Retorna true se aceitou o lance, false caso contrário.
     */
    public boolean bidFor(Bid bid) {
        if (bid == null) {
            return false;
        }
        if (highestBid == null || bid.getValue() > highestBid.getValue()) {
            highestBid = bid;
            return true;
        } else {
            return false;
        }
    }

    /**
     * Alias / alternativa: aceitar um lance através de dados brutos
     */
    public boolean bid(Person p, int value) {
        return bidFor(new Bid(p, value));
    }

    public String toString() {
        String result = "Lote " + number + ": " + description;
        if (highestBid != null) {
            result += " | Lance: " + highestBid.getValue() + " (por " + highestBid.getBidder().getName() + ")";
        } else {
            result += " | (sem lances)";
        }
        return result;
    }
}
