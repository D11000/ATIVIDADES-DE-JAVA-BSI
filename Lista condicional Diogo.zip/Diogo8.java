import java.util.Scanner;
public class Diogo8 {
    public static void  main (String[] args)
    {
        Scanner entrada = new Scanner(System.in);
        int basemaior;
        int basemenor;
        int altura;

        int areatotal;
        int valordevenda;
        basemaior= 50;
        basemenor= 50;
        altura=50;
        areatotal=basemaior+basemenor*altura/2;
        valordevenda=areatotal*100;
    System.out.println("A area total é:" +" "+ areatotal + "\n"+ "o valor de venda é:"+ " "+ valordevenda);



    }











    }











