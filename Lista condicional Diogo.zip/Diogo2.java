//2. Ler um número inteiro e imprimir o seu sucessor e seu antecessor.

import java.util.Scanner;

public class Diogo2 {
    public static void main(String[] args) {
        int a,b,c ;
        Scanner dados= new Scanner(System.in);
        System.out.println("Digite o  valor ");
        a= dados.nextInt();
        c= a+1;
        b= a-1;
        System.out.println("O antecessor de " +a+  "é" +b+ " e o sucessor é " +c);








    }









}
