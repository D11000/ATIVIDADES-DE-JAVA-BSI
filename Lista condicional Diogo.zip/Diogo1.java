//1. Crie um algoritmo que calcule a soma e a média de 3 números informados pelo usuário.

import java.util.Scanner;

public class Diogo1 {
    public static void main(String[] args) {
int a, b,c,d;
        Scanner dados = new Scanner(System.in);
        System.out.println("Digite o  valor ");

        a= dados.nextInt();
        System.out.println("Digite o  valor ");
        b= dados.nextInt();
        System.out.println("Digite o valor ");
        c= dados.nextInt();
        d=a+b+c/3;
        System.out.println("a media é "+d);


    }








}
