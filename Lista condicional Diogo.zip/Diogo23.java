import java.util.Scanner;


public class Diogo23 {
    public static void main(String[] args)
    {
        int Pessoas = 3000;int A = 1450;int B = 1150;int C = 900;int AeB = 350;int AeC = 400;int BeC = 300;int AeBeC = 100;
        int Conjuntos= A+B+C-AeB-AeC-BeC+AeBeC;
        int Nenhuma= Pessoas- Conjuntos;



                System.out.println("O Número de pessoas que não gostam de nenhuma novela é: " + Nenhuma);
            }





}